﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PrototypeDesignPattern
{
    public abstract class ShapeClass
    {
        public float x;
        public float y;
        public String color;

        public ShapeClass() {

        }

        public ShapeClass(ShapeClass target) {
            if (target != null) {
                x = target.x;
                y = target.y;
                color = target.color;
            }
        }

        public abstract ShapeClass clone();

    }
}
