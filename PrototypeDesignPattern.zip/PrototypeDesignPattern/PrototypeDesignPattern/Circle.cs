﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeDesignPattern
{
    public class Circle : ShapeClass
    {
        public float radius;

        public Circle() {

        }

        public Circle(Circle target) : base(target) {
            if (target != null) {
                radius = target.radius;
            }
        }

        override
            public ShapeClass clone(){
            return new Circle(this);
        }

        public Boolean identical(Object obj2) {
            if (!(obj2 is Circle || base.Equals(obj2))){
                return false;
            }

            Circle sh2 = (Circle)obj2;
            return sh2.radius == radius;
        }

    }
}
