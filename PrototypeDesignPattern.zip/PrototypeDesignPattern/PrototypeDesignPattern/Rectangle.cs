﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeDesignPattern
{
    public class Rectangle : ShapeClass
    {
        public float width;
        public float height;

        public Rectangle() {
        }

        public Rectangle(Rectangle target) : base(target) {
            if (target != null){
                width = target.width;
                height = target.height;
            }
        }

        override
            public ShapeClass clone(){
            return new Rectangle(this);
        }

        public Boolean identical(Object obj2)
        {
            if (!(obj2 is Rectangle || base.Equals(obj2)))
            {
                return false;
            }

            Rectangle sh2 = (Rectangle)obj2;
            return sh2.width == width && sh2.height == height;
        }

    }
}
