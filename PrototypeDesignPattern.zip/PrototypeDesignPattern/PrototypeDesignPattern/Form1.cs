﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototypeDesignPattern
{
    public partial class Form1 : Form
    {
        float x, y, width, height, radius, diameter, circle_width, circle_height;
        string color;

        

        public Form1()
        {
            InitializeComponent();
        }

        public void getUserInput()
        {
            color = cbColors.SelectedItem.ToString();

            if (cbShapes.SelectedItem.Equals("Rectangle"))
            {
                if (txtXCoordinate.Text.Equals("") || txtYCoordinate.Text.Equals("") || txtWidth.Text.Equals("") || cbColors.SelectedIndex == -1)
                {
                    MessageBox.Show("Please fill up the missing fields.");
                }
                else
                {
                    x = (float)Convert.ToDouble(txtXCoordinate.Text);
                    y = (float)Convert.ToDouble(txtYCoordinate.Text);
                    width = (float)Convert.ToDouble(txtWidth.Text);
                    height = (float)Convert.ToDouble(txtHeight.Text);

                    color = cbColors.SelectedItem.ToString();
                }
                
            }
            else if (cbShapes.SelectedItem.Equals("Circle"))
            {
                if (txtXCoordinate.Text.Equals("") || txtYCoordinate.Text.Equals("") || txtRadius.Text.Equals("") || cbColors.SelectedIndex == -1)
                {
                    MessageBox.Show("Please fill up the missing fields.");
                }
                else
                {
                    x = (float)Convert.ToDouble(txtXCoordinate.Text);
                    y = (float)Convert.ToDouble(txtYCoordinate.Text);
                    radius = (float)Convert.ToDouble(txtRadius.Text);

                    color = cbColors.SelectedItem.ToString();
                }
               
            }
        }

        public void getRectangleCoordinates()
        {
           Rectangle rect = new Rectangle();
           rect.x = x;
           rect.y = y;
           rect.width = width;
           rect.height = height;
           rect.color = color;
               
            SolidBrush sb = new SolidBrush(Color.FromName(color));
            Graphics g = pnlShapes.CreateGraphics();

            g.FillRectangle(sb, rect.x, rect.y, rect.width, rect.height);
        }

        public void getCircleCoordinates()
        {
            Circle cir = new Circle();
            cir.x = x;
            cir.y = y;
            cir.radius = radius;

            diameter = radius * 2;
            circle_width = diameter * diameter;
            circle_height = diameter * diameter;

            SolidBrush sb = new SolidBrush(Color.FromName(color));
            Graphics g = pnlShapes.CreateGraphics();

            g.FillEllipse(sb, cir.x, cir.y, circle_width, circle_height);
        }

        public void clearAll()
        {
            cbShapes.SelectedIndex = -1;
            cbColors.SelectedIndex = -1;
            txtXCoordinate.Text = "";
            txtYCoordinate.Text = "";
            txtWidth.Text = "";
            txtHeight.Text = "";
            txtRadius.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] shapes = new string[]
            {
                "Rectangle",
                "Circle"
            };

            string[] colors = new string[]
               {
                    "Red",
                    "Yellow",
                    "Blue",
                    "Orange",
                    "Green",
                    "Gray"
            };

            for (int i = 0; i < shapes.Length; i++)
            {
                cbShapes.Items.Add(shapes[i].ToString());
            }

            for (int j = 0; j < colors.Length; j++)
            {
                cbColors.Items.Add(colors[j].ToString());
            }

        }

        private void cbShapes_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbShapes.SelectedIndex == -1)
            {

            }
            else if (cbShapes.SelectedItem.Equals("Rectangle"))
            {
                lblWidth.Visible = true;
                txtWidth.Visible = true;
                lblHeight.Visible = true;
                txtHeight.Visible = true;

                lblRadius.Visible = false;
                txtRadius.Visible = false;  
            }
            else if (cbShapes.SelectedItem.Equals("Circle"))
            {
                lblWidth.Visible = false;
                txtWidth.Visible = false;
                lblHeight.Visible = false;
                txtHeight.Visible = false;

                lblRadius.Visible = true;
                txtRadius.Visible = true;
            }

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (cbShapes.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a corresponding shape.");
            }
            else if (cbColors.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a corresponding color.");
            }
            else if (cbShapes.SelectedItem.Equals("Rectangle"))
            {
                getUserInput();
                getRectangleCoordinates();
            }
            else if (cbShapes.SelectedItem.Equals("Circle"))
            {
                getUserInput();
                getCircleCoordinates();
            }

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            clearAll();
            pnlShapes.Refresh();
        }

    }
}
